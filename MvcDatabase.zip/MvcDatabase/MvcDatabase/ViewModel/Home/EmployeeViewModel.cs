﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcDatabase.Models;
using System.Configuration;
using System.Data.SqlClient;

namespace MvcDatabase.ViewModel.Home
{
    public class EmployeeViewModel
    {
        // Dataset DataTable List Collection Array
        public List<Employee> GetAllEmployee() 
        {
            List<Employee> employee = new List<Employee>();
            String constring = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("usp_EmployeesGetAllEmployees", conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Employee emp = new Employee();
                        emp.EmployeeId =Convert.ToInt16( reader["EmployeeId"]);
                        emp.Name = reader["Name"].ToString();
                        emp.Email = reader["Email"].ToString();
                        emp.Mobile = reader["Mobile"].ToString();
                        employee.Add(emp);
                    }
                }
            }
            return employee;
        }

        public void AddNewEmployee(Employee employee)
        {
            string connString = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
            using(SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("usp_EmployeeAddNewEmployee", conn))
                {
                    conn.Open();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name",employee.Name);
                    cmd.Parameters.AddWithValue("@Email", employee.Email);
                    cmd.Parameters.AddWithValue("@Mobile", employee.Mobile);
                    cmd.ExecuteNonQuery();
                }

            }
        }
        public Employee GetById(int id)
        {
            Employee emp = new Employee();
            String constring = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("usp_EmployeesGetAllEmployeeById", conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    conn.Open();
                    cmd.Parameters.AddWithValue("@id", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                    emp.EmployeeId = Convert.ToInt16(reader["EmployeeId"]);
                    emp.Name = reader["Name"].ToString();
                    emp.Email = reader["Email"].ToString();
                    emp.Mobile = reader["Mobile"].ToString(); 
                }
            }

            return emp;
        }

        public void UpdaetEmployee(Employee employee)
        {
            String constring = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("usp_EmployeeUpdaetById", conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    conn.Open();
                    cmd.Parameters.AddWithValue("@id",employee.EmployeeId);
                    cmd.Parameters.AddWithValue("@Name", employee.Name);
                    cmd.Parameters.AddWithValue("@Email", employee.Email);
                    cmd.Parameters.AddWithValue("@Mobile", employee.Mobile);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Delete(int id)
        {
             String constring = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
             using (SqlConnection conn = new SqlConnection(constring))
             {
                 using (SqlCommand cmd = new SqlCommand("usp_EmployeeDeleteById", conn))
                 {
                     cmd.CommandType = System.Data.CommandType.StoredProcedure;
                     conn.Open();
                     cmd.Parameters.AddWithValue("@id", id);
                     cmd.ExecuteNonQuery(); 
                 }
             }    
        }
    }
}