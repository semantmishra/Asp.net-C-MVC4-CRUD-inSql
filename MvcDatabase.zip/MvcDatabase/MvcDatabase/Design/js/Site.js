﻿$(document).ready(function () {
    $('#jstable').dataTable();

});

$(document).ready(function () {
    $('#gd').dataTable({
        "scrollY" : "50vh",
        "paging" : false
    });
});


$(document).ready(function () {
    $('#ajax').dataTable({
    "scrollY" : "50vh",
        "paging" : false,
        "ajax": {
            "url": "/Home/Student",
            "type": "Get",
            "datatype": "json"
        },
        "columns": [
                { "data": "EmployeeId" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Mobile" }
           ]
    });
});


$(document).ready(function () {
    var table = $('#ajaxTable2').DataTable({
        "ajax": {
            "url": "/Home/Student",
            "type": "Get",
            "datatype": "json"
        },
        "columns": [
                { "data": "EmployeeId" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Mobile" }
           ],
        dom: 'lfBrtpi',
        buttons: [
              'copy', 'excel', 'csv', 'pdf', 'print'
           ]

    });
    table.buttons().container().appendTo($('#printbar'));
});