﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcDatabase.ViewModel.Home;
using MvcDatabase.Models;

namespace MvcDatabase.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            EmployeeViewModel e = new EmployeeViewModel();
            List<Employee> employee = e.GetAllEmployee();

            return View(employee);
        }
        public ActionResult Create()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                EmployeeViewModel empVM = new EmployeeViewModel();
                empVM.AddNewEmployee(employee);
                ViewBag.M = "<script>alert('Save succesfull')</script>";
                return RedirectToAction("Create");    
            }
            return View();
        }

        public ActionResult Details(int id)
        {
            EmployeeViewModel EVM = new EmployeeViewModel();
            Employee employee = EVM.GetById(id);
            return View(employee);
        }

        public ActionResult Edit(int id)
        {
            EmployeeViewModel EVM = new EmployeeViewModel();
            Employee employee = EVM.GetById(id);
            return View(employee);
        }
        [HttpPost]
        public ActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                EmployeeViewModel EVM = new EmployeeViewModel();
                EVM.UpdaetEmployee(employee);
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Delete(int id)
        {

            EmployeeViewModel EVM = new EmployeeViewModel();
            EVM.Delete(id);
            return RedirectToAction("Index");
        }
        public ActionResult Ajax()
        {
            return View();
        }
       
        

        public ActionResult GirdView()
        {
            EmployeeViewModel e = new EmployeeViewModel();
            List<Employee> employee = e.GetAllEmployee();
            return View(employee);
        }
        public ActionResult Student()
        {
            EmployeeViewModel e = new EmployeeViewModel();
            List<Employee> employee = e.GetAllEmployee();
            return Json(new { data = employee }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Ajax2()
        {

            return View();
        }
    }
}
