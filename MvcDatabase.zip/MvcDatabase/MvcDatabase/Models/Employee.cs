﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcDatabase.Models
{
    public class Employee
    {
        [Display(Name="Id:")]
        public int EmployeeId { get; set; }
        [Required(ErrorMessage="Enter Name")]
        [Display(Name = "Name:")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Enter Email")]
        [Display(Name = "Email:")]
        public String Email { get; set; }
        [Required(ErrorMessage = "Enter Mobile")]
        [Display(Name = "Mobile:")]
        public string Mobile { get; set; }
    }
}